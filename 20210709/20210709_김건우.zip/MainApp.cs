﻿using System; // Console 라이브러리 사용
using static System.Console; // Console 을 생략 가능하게 만들어 줌

// 네임스페이스
namespace ConsoleApp3
{
    // 클래스
    class MainApp
    {
        // 메인 함수 : 프로그램의 시작 이며 끝
        // 인자 : 문자열 배열형 args
        // 반환 : void (없음)
        static void Main(string[] args)
        {
            // 조건문 : 인자로 받은 문자열이 하나도 없는가?
            if (args.Length == 0)
            {
                // 라이브러리 Console 의 WriteLine 함수 사용
                // 위 함수는 콘솔창에 문자등을 출력하는 역할을 한다
                Console.WriteLine("사용법 : Hellow.exe <이름>");

                // 프로그램 종료
                // return 문은 두가지 기능을 지니는데 하나는 값의 반환 다른 하나는 함수의 종료
                return;
            }

            // 인자로 받은 문자열 중 첫번째를 출력한다
            WriteLine("Hello, {0}", args[0]);
        }
    }
}


