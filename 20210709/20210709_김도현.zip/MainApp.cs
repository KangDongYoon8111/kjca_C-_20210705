﻿using System; //using(키워드) System(클래스) System네임스페이스를 사용하겠다고 컴파일러에게 알림.
using static System.Console; // using static System 클래스의 정적멤버를 데이터 형식의 이름을 명시하지 않고 참조하겠다고 선언하는 기능

namespace ConsoleApp2 //ConsoleApp2라는 이름아래 동일한 성격이나 하는 일이 비슷한 것들을 묶겠다.
{
    class MainApp //MainApp 이라는 클래스 기능을 하나 만들겠다.
    {
        static void Main(string[] args) //한정자, 반환형식 , 메소드(함수)이름, 매개변수 - 프로그램의 시작점을 알려줌
        {
            if (args.Length == 0) // 매개변수의 길이가 0일 때 안내문을 출력하고 프로그램을 종료시킴
            {
                WriteLine("사용법 : ConsoleApp2.exe <이름>"); //매개변수의 길이가 0일 때 나올 안내문
                return; //메소드를 종료하는 용도로 사용
            }

            WriteLine("Hello, {0}", args[0]); //프롬프트에 출력되는 문구
        }
    }
}
