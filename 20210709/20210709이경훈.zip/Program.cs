﻿using System;
// 키워드 uising( 사용할게요) System 이라는 namespace요!
using static System.Console;
// 키워드 using static (사용할게요) System이라는 namespace에서 Console 이라는 클래스를요!

namespace Frist_Huni
// 이 namespace의 이름은 Frist_Huni 입니다
{
    class MainApp
        // 이 클래스의 이름은 MainApp 입니다
    {
        static void Main(string[] args)
            // static으로 수식되어 있는 Main 메소드로 프로그램 실행시 진입을 유도합니다 (없으면 실행안되요)
        {
            if (args.Length == 0)
                // 만약 args라는 집합에 값이 없다면 실행하세요
            {
                WriteLine("사용법 : Hellow.exe <이름>"); // ("사용법 : Hellow.exe <이름>")를 한줄 입력하세요 
                return;     // 값은 void에 반환합니다
            }
            WriteLine("WOW, \n {0}는 생각보다 똑똑하구나!!",args[0]);
            // args[0] 값을 받아와서 "WOW, \n {0}는 생각보다 똑똑하구나!!"를  입력합니다
        }
    }
}
