﻿using System;//System 네임스페이스 사용 선언. System. 생략 가능
using static System.Console;//System 네임스페이의 Console 클래스 사용 선언. System.Console. 생략 가능

namespace _210709//_210709 라는 이름의 네임스페이스 선언
{
    class Hello//Hello 클래스 선언
    {
        static void Main(string[] args)//void 반환값을 갖는 메인함수 시작
        {
            if (args.Length == 0)//args의 값이 0일(입력값이 0일 경우) 진입
            {
                Console.WriteLine("사용법 : Hello.exe <이름>");//Console클래스의 WriteLine함수를 사용해 사용법 출력
                return;//종료
            }
            WriteLine("Hello, {0}!", args[0]);//WriteLine 함수를 사용하여 args(입력값)을 포함한 문장 출력
        }
    }
}
