﻿using System; //System 사용
using static System.Console; //Console 기능 사용

namespace _7._9_test //네임스페이스(비슷한 기능의 클래스 그룹) 명
{
    class Program //클래스/클래스명
    {
        static void Main(string[] args) //클래스 시작점
        {
            if (args.Length == 0) //프로그램 실행 시 아무것도 입력 안 하면
            {
                Console.WriteLine("사용법 : Hello.exe <이름>"); //콘솔에서 사용법 출력
                return; //if문 종료
            }

            WriteLine("Hello, {0}", args[0]); //프로그램 실행 시 1글자 이상 입력시 Hello, 입력한 문자 출력
        }
    }
}
