﻿using System;//c#의 키워드 using 키워드란 미리 정의되어 있는 특별한 단어입니다.system은 네임스페이스안에 있는 클래스를 사용하겠다고 컴파일러에 알리는 역할을 합니다. 세미콜론으로 그 줄의 소스를 끝냅니다.
using static System.Console;//콘솔 메소드를 사용하기 위한 정의입니다. using static은 어떤 데이터형식의 정적멤버를 데이터형식의 이름을 명시하지 않고 참조하겠다고 선언하는 기능입니다.

namespace _20210709//전체적인 대표 묶음을 명칭한다
{
    class Program// 클래스 이름 프로그램으로 입력되어 있다.
    {
        static void Main(string[] args)//크게 말하면 메소드입니다.  static은 한정자 void는 반환형식 Main은 메소드이름 (string[] args)는 매개변수
        {
            
            if(args.Length == 0)//조건문.if문소괄호 안에 조건이 만족하면 중괄호 식을 시행하고 그렇지 않으면 WriteLine("Hello,{0}!", args[0]);로 바로 넘어간다.
            {
                Console.WriteLine("사용법 : Hello.exe <이름>");//WriteLine메소드를 사용해서 소괄호에 있는 내용을 출력한다.
                return;//원래 메소드의 호출자에게 메소드 실행결과를 돌려주는 역할을 하지만, 여기서는 메소드 종요하는 용도로만 사용됨
            }

            WriteLine("Hello,{0}!", args[0]);//화면추력 메소드 WriteLine를 사용하여 소괄호 안에 있는 내용을 출력한다.
                                             //출력할 내용중 {0}는 콤마 다음에 설정된 args[0]의 저장된 값중 0번 순서를 받아봐서출력한다.

        }
    }
}
