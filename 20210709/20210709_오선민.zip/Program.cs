﻿using System; // system이라고 지정한 네임스페이스를 사용하겠다.
using static System.Console; // 콘솔 클래스의 이름을 명시하지 않고 참조하겠다.

namespace p19_ex1 // 성격이나 하는 일이 비슷한 기능들을 p19_ex1이라는 이름 아래에 묶겠다.
{
    class Program // Program이라고 명하는 기능을 만들겠다.
    {
        static void Main(string[] args) // 프로그램 시작 시 출발점
        {
            if (args.Length == 0) // 만약 매개변수의 길이가 0이라면 이라는 조건문이다.
            {
                Console.WriteLine("사용법 : Hello.exe<이름>"); // "콘솔 클래스의 메소드를 이용하여 괄호 안의 내용을 출력하겠다.
                return; // 조건문의 종료
            }

            WriteLine("Hello, {0}!", args[0]); // 콘솔 클래스의 메소드를 이용해서 괄호 안의 내용을 콘솔에 출력하겠다.


        }
    }

}