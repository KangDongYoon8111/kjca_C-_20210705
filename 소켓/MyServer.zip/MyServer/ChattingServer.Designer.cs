﻿namespace MyServer
{
    partial class ChattingServer
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_log = new System.Windows.Forms.ListBox();
            this.tb_port = new System.Windows.Forms.TextBox();
            this.tb_send = new System.Windows.Forms.TextBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_send = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_log
            // 
            this.lb_log.FormattingEnabled = true;
            this.lb_log.ItemHeight = 12;
            this.lb_log.Location = new System.Drawing.Point(12, 39);
            this.lb_log.Name = "lb_log";
            this.lb_log.Size = new System.Drawing.Size(604, 364);
            this.lb_log.TabIndex = 0;
            // 
            // tb_port
            // 
            this.tb_port.Location = new System.Drawing.Point(12, 12);
            this.tb_port.Name = "tb_port";
            this.tb_port.Size = new System.Drawing.Size(442, 21);
            this.tb_port.TabIndex = 1;
            // 
            // tb_send
            // 
            this.tb_send.Location = new System.Drawing.Point(12, 417);
            this.tb_send.Name = "tb_send";
            this.tb_send.Size = new System.Drawing.Size(523, 21);
            this.tb_send.TabIndex = 2;
            this.tb_send.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_send_KeyDown);
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(460, 12);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(75, 23);
            this.btn_start.TabIndex = 3;
            this.btn_start.Text = "시작";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(541, 10);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 23);
            this.btn_clear.TabIndex = 4;
            this.btn_clear.Text = "지우기";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_send
            // 
            this.btn_send.Location = new System.Drawing.Point(541, 417);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(75, 23);
            this.btn_send.TabIndex = 5;
            this.btn_send.Text = "보내기";
            this.btn_send.UseVisualStyleBackColor = true;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // ChattingServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 450);
            this.Controls.Add(this.btn_send);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.tb_send);
            this.Controls.Add(this.tb_port);
            this.Controls.Add(this.lb_log);
            this.Name = "ChattingServer";
            this.Text = "체팅 서버";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_log;
        private System.Windows.Forms.TextBox tb_port;
        private System.Windows.Forms.TextBox tb_send;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_send;
    }
}

