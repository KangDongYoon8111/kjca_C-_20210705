﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;

namespace MyServer
{
    public partial class ChattingServer : Form
    {
        delegate void DelWriteLog(Control control, string text);
        DelWriteLog delWriteLog;
        delegate void DelSelectedIndex(Control control);
        DelSelectedIndex delSelectedIndex;
        delegate void DelSetText(Control control, string text);
        DelSetText delSetText;

        Socket server = null;
        List<Socket> clients = new List<Socket>();
        IPAddress ip = null;

        public ChattingServer()
        {
            InitializeComponent();

            delWriteLog = new DelWriteLog(WriteLog);
            delSelectedIndex = new DelSelectedIndex(SelectedIndex);
            delSetText = new DelSetText(SetText);

            SetDefaultIP(); // 아이피와 포트의 기본값을 설정한다

            server = CreateSocket(); // 소켓을 만든다
        }

        // 시작 버튼 클릭 이벤트
        private void btn_start_Click(object sender, EventArgs e)
        {
            int port = 0;
            if (!int.TryParse(tb_port.Text, out port))
            {
                WriteLog(lb_log, "포트번호를 확인해주세요.");
                tb_port.Focus();
                return;
            }

            if (server.IsBound)
            {
                WriteLog(lb_log, "서버가 이미 실행중입니다.");
                return;
            }

            // 서버에서 클라이언트의 연결 요청을 대기하기 위해 소켓을 열어둔다.
            server.Bind(new IPEndPoint(ip, port));
            server.Listen(10);

            // 비동기적으로 클라이언트의 연결 요청을 받는다.
            WriteLog(lb_log, "서버 대기중...");
            server.BeginAccept(AcceptCallback, null);
        }

        void AcceptCallback(IAsyncResult result)
        {
            Socket client = server.EndAccept(result); // 클라이언트의 연결 요청을 수락한다.

            server.BeginAccept(AcceptCallback, null); // 또 다른 클라이언트의 연결을 대기한다.

            AsyncObject obj = new AsyncObject(4096);
            obj.socket = client;

            clients.Add(client); // 클라이언트 리스트에 추가해준다.

            // 클라이언트의 데이터를 받는다.
            client.BeginReceive(obj.buffer, 0, obj.bufferSize, 0, ReceiveCallback, obj);
            WriteLog(lb_log, "클라이언트 연결되었습니다. : " + client.RemoteEndPoint);
        }

        void ReceiveCallback(IAsyncResult result)
        {
            AsyncObject obj = (AsyncObject)result.AsyncState;

            try
            {
                int received = obj.socket.EndReceive(result); // 데이터 수신을 끝낸다.
                if (received <= 0)
                {
                    obj.socket.Close(); // 받은 데이터가 없으면(연결끊어짐) 끝낸다.
                    CloseAllClients(); // 모든 클라이언트의 접속을 종료한다
                    server = CreateSocket(); // 소켓을 만든다
                    WriteLog(lb_log, "오류로 인한 서버 종료");
                    return;
                }
            }
            catch
            {
                string test = "test" + '\x01' + "test" + '\x01' + "test";
                SendToClients(test); // 소켓 유지하면서 클라이언트들 확인
                return;
            }

            string text = Encoding.UTF8.GetString(obj.buffer); // 텍스트로 변환한다
            string[] tokens = text.Split('\x01'); // 0x01 기준으로 짜른다
            if (tokens[0] == "chat")
            {
                WriteLog(lb_log, "[받음]" + tokens[1] + " : " + tokens[2]);
                SendToClients(text, obj.socket); // 메시지 송신 클라이언트 제외하고 모든 클라이언트에게 전송한다.
            }
            
            obj.ClearBuffer(); // 버퍼 초기화
            obj.socket.BeginReceive(obj.buffer, 0, obj.bufferSize, 0, ReceiveCallback, obj); // 수신 대기
        }

        // 지우기 버튼 클릭 이벤트
        private void btn_clear_Click(object sender, EventArgs e)
        {
            lb_log.Items.Clear();
        }

        // 보내기 버튼 클릭 이벤트
        private void btn_send_Click(object sender, EventArgs e)
        {
            if (tb_send.Text.Length <= 0) { return; }

            // 서버가 대기중인지 확인한다.
            if (!server.IsBound)
            {
                WriteLog(lb_log, "서버가 실행되고 있지 않습니다!");
                return;
            }

            string text = "chat" + '\x01' + ip.ToString() + '\x01' + tb_send.Text;
            SendToClients(text); // 연결된 모든 클라이언트에게 전송한다.

            if (clients.Count > 0)
            {
                WriteLog(lb_log, "[보냄]" + ip.ToString() + " : " + tb_send.Text);
            }
        }

        // 모든 클라이언트의 접속을 종료한다
        public void CloseAllClients()
        {
            for (int i = clients.Count - 1; i >= 0; i--)
            {
                clients[i].Close();
                clients.RemoveAt(i);
            }
        }

        // 연결된 모든 클라이언트에게 전송한다.
        public void SendToClients(string text, Socket sender = null)
        {
            byte[] buff = Encoding.UTF8.GetBytes(text);

            for (int i = clients.Count - 1; i >= 0; i--)
            {
                if (sender != null && clients[i] == sender) { continue; } // 클라이언트 중 송신자는 제외한다.

                try { clients[i].Send(buff); }
                catch
                {
                    try { clients[i].Dispose(); } catch { }
                    clients.RemoveAt(i); // 오류 발생시 리스트에서 삭제한다.
                    WriteLog(lb_log, "클라이언트 삭제 : " + i.ToString() + "/" + clients.Count.ToString());
                }
            }
        }

        // 보내기 텍스트 엔터키 입력 이벤트
        private void tb_send_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) { return; }

            btn_send_Click(null, null);
        }

        // 소켓을 만든다
        public Socket CreateSocket()
        {
            return new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
        }

        // 아이피와 포트의 기본값을 설정한다
        public void SetDefaultIP()
        {
            IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress addr in hostEntry.AddressList)
            {
                if (addr.AddressFamily == AddressFamily.InterNetwork)
                {
                    ip = addr;
                    break;
                }
            }
            if (ip == null) { ip = IPAddress.Loopback; }

            tb_port.Text = "15000";
        }

        // 로그를 남긴다
        public void WriteLog(Control control, string text = "")
        {
            if (text.Length == 0) { return; }

            if (control.InvokeRequired) { control.Invoke(delWriteLog, control, text); }
            else { lb_log.Items.Add(text); }

            SelectedIndex(lb_log);
            SetText(tb_send, "");
        }
        public void SelectedIndex(Control control)
        {
            if (control.InvokeRequired) { control.Invoke(delSelectedIndex, control); }
            else { lb_log.SelectedIndex = lb_log.Items.Count - 1; }
        }
        public void SetText(Control control, string text = "")
        {
            if (control.InvokeRequired) { control.Invoke(delSetText, control, text); }
            else { tb_send.Text = text; }
        }
    }
}
