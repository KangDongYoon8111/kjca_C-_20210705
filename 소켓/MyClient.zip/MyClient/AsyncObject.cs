﻿using System;
using System.Net.Sockets;

namespace MyClient
{
    public class AsyncObject
    {
        public byte[] buffer = null;
        public int bufferSize = 0;
        public Socket socket = null;

        public AsyncObject(int bufferSize = 1024)
        {
            this.bufferSize = bufferSize;
            buffer = new byte[bufferSize];
        }

        public void ClearBuffer()
        {
            Array.Clear(buffer, 0, bufferSize);
        }
    }
}
