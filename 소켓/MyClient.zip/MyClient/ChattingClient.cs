﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace MyClient
{
    public partial class ChattingClient : Form
    {
        delegate void DelWriteLog(Control control, string text);
        DelWriteLog delWriteLog;
        delegate void DelSelectedIndex(Control control);
        DelSelectedIndex delSelectedIndex;
        delegate void DelSetText(Control control, string text);
        DelSetText delSetText;

        Socket client = null; // 클라이언트 소켓

        public ChattingClient()
        {
            InitializeComponent();

            delWriteLog = new DelWriteLog(WriteLog);
            delSelectedIndex = new DelSelectedIndex(SelectedIndex);
            delSetText = new DelSetText(SetText);

            SetDefaultIP(); // 아이피와 포트의 기본값을 설정한다

            client = CreateSocket(); // 소켓을 만든다
        }

        // 접속 버튼 클릭 이벤트
        private void btn_conn_Click(object sender, EventArgs e)
        {
            if (client.Connected) { WriteLog(lb_log, "이미 연결되어 있습니다."); return; }
            if (tb_ip.Text == "") { WriteLog(lb_log, "아이피를 확인해주세요."); tb_ip.Focus(); return; }
            
            int port = 0;
            if (!int.TryParse(tb_port.Text, out port))
            {
                WriteLog(lb_log, "포트번호를 확인해주세요.");
                tb_port.Focus();
                return;
            }

            try
            {
                client.Connect(tb_ip.Text, port);
            }
            catch (Exception ex)
            {
                WriteLog(lb_log, "서버접속 실패 : " + ex.Message);
                return;
            }

            WriteLog(lb_log, "서버에 연결되었습니다.");

            AsyncObject obj = new AsyncObject(4096);
            obj.socket = client;
            client.BeginReceive(obj.buffer, 0, obj.bufferSize, 0, ReceiveCallback, obj); // 수신대기
        }

        public void ReceiveCallback(IAsyncResult result)
        {
            AsyncObject obj = (AsyncObject)result.AsyncState;

            try
            {
                int received = obj.socket.EndReceive(result);
                if (received <= 0)
                {
                    obj.socket.Close();
                    client = CreateSocket(); // 소켓을 만든다
                    WriteLog(lb_log, "받은 데이터가 없어서 연결 해제");
                    return;
                }
            }
            catch (Exception ex)
            {
                obj.socket.Close();
                client = CreateSocket(); // 소켓을 만든다
                WriteLog(lb_log, "연결 해제 : " + ex.Message);
                return;
            }

            string text = Encoding.UTF8.GetString(obj.buffer); // 텍스트로 변환한다
            string[] tokens = text.Split('\x01'); // 0x01 기준으로 짜른다
            if (tokens[0] == "chat")
            {
                WriteLog(lb_log, "[받음]" + tokens[1] + " : " + tokens[2]);
            }

            obj.ClearBuffer(); // 버퍼 초기화
            obj.socket.BeginReceive(obj.buffer, 0, obj.bufferSize, 0, ReceiveCallback, obj); // 수신대기
        }

        // 클리어 버튼 클릭 이벤트
        private void btn_clear_Click(object sender, EventArgs e)
        {
            lb_log.Items.Clear();
        }

        // 보내기 버튼 클릭 이벤트
        private void btn_send_Click(object sender, EventArgs e)
        {
            if (tb_send.Text.Length <= 0) { return; }

            if (!client.IsBound)
            {
                WriteLog(lb_log, "서버에 접속 중이 아닙니다.");
                return;
            }

            // 서버 ip 주소와 메세지를 담도록 만든다
            IPEndPoint endPoint = (IPEndPoint)client.LocalEndPoint;
            string ip = endPoint.Address.ToString();
            string text = "chat" + '\x01' + ip + '\x01' + tb_send.Text;
            byte[] buff = Encoding.UTF8.GetBytes(text);

            client.Send(buff); // 서버에 전송한다
            WriteLog(lb_log, "[보냄]" + ip + " : " + tb_send.Text);
        }

        // 보내기 텍스트 엔터키 입력 이벤트
        private void tb_send_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) { return; }

            btn_send_Click(null, null);
        }

        // 소켓을 만든다
        public Socket CreateSocket()
        {
            return new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
        }

        // 아이피와 포트의 기본값을 설정한다
        public void SetDefaultIP()
        {
            IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ip = null;
            foreach (IPAddress addr in hostEntry.AddressList)
            {
                if (addr.AddressFamily == AddressFamily.InterNetwork)
                {
                    ip = addr;
                    break;
                }
            }
            if (ip == null) { ip = IPAddress.Loopback; }

            tb_ip.Text = ip.ToString();
            tb_port.Text = "15000";
        }

        // 로그를 남긴다
        public void WriteLog(Control control, string text = "")
        {
            if (text.Length == 0) { return; }

            if (control.InvokeRequired) { control.Invoke(delWriteLog, control, text); }
            else { lb_log.Items.Add(text); }

            SelectedIndex(lb_log);
            SetText(tb_send, "");
        }
        public void SelectedIndex(Control control)
        {
            if (control.InvokeRequired) { control.Invoke(delSelectedIndex, control); }
            else { lb_log.SelectedIndex = lb_log.Items.Count - 1; }
        }
        public void SetText(Control control, string text = "")
        {
            if (control.InvokeRequired) { control.Invoke(delSetText, control, text); }
            else { tb_send.Text = text; }
        }
    }
}
