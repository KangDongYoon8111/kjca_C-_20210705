﻿using System; //system 네임스페이스 안에 있는 클래스를 사용하겠다고 컴파일러에 알림
using static System.Console; //console class의 정적 멤버(write(), read() 등)를 데이터 형식의 이름을 명시하지 않고 참조하겠다는 선언

namespace HomeWork //성격이나 하는 일이 비슷한 클래스, 구조체 등을 HomeWork 이름 아래 묶어놓음
{
    class MainApp //MainApp이라는 클래스를 만듦
    {
        static void Main(string[] args) //static 한정자와 void(결과를 반환하지않겠다고 컴파일러에게 알려줌)를 사용해 main메소드(프로그램의 진입점, 코드에 무조건 있어야함) 수식
        {
            if (args.Length == 0) //if함수를 이용해 문자열 변수 args의 길이가 0과 같다면 입력되지 않았다고 판단함
            {
                WriteLine("사용법 : Hello.exe <이름>"); //사용자에게 사용법을 알려줌
                return; //main 메소드 종료
            }

            WriteLine("Hello, {0}!", args[0]); //문자열 변수에 입력된 값을 {0}자리에 출력함
        }
    }
}
