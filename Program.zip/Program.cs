﻿//키워드 네임스페이스 : system이라는 name space안에 클래스 (기능)를 사용하겠다
using System;
using static System.Console;
// hello 라는 네임스페이스를 만들겠다
namespace Hello
{
    // MainApp이라는 클래스를 만들겠다 
    class MainApp
    {
        //프로그램 실행이 시작되는 곳
        static void Main(string[] args)
        {
            //만약 아무것도 입력되지 않으면
            if (args.Length == 0)
            //사용법 : Hello.exe <이름>을 출력
            {
                Console.WriteLine("사용법 : Hello.exe <이름>");
                //종료
                return;

            }
            // 제대로 입력되면 Hello (변수) 출력
            WriteLine("Hello, {0}!", args[0]);
        }
    }
}
