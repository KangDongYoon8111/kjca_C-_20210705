﻿using System;

namespace _20210716_성민식
{
    class Program
    {
        static void Main(string[] args)
        {
        // 1. 아래 4가지 형태의 변수를 선언해주세요.
        bool q = true;// 논리형 :
        string w = "Hello";// 문자형 :
        int e = 1;// 정수형 :
        float r = 3.14f;// 소수형 :


        // 2. 생년월일를 숫자로 저장하고자 한다. 이 값을 저장하기 위해서는 어떤 데이터형(data type)을 선택해야 할까?
        //    myYear라는 이름의 변수를 선언하고 자신의 생년월일로 초기화하는 한 줄의 코드를 적으시오.
        int myYear = 19990304;

        // 3. 주민등록번호를 숫자로 저장하고자 한다. 이값을 저장하기 위해서는 어떤 데이터형(data type)을 선택해야 할까?
        //    regNo라는 이름의 변수를 선언하고 자신의 생년월일로 초기화하는 한 줄의 코드를 적으시오.
        long regNo = 990304;

            // 4. 다음 문장들의 출력 결과를 적으세요. 오류가 있는 문장의 경우, '오류'라고 적으시오.
            // Console.WriteLine("1" + "2"); = 12
            // Console.WriteLine(true + ""); = True 
            // Console.WriteLine('A'+'B'); = 131
            // Console.WriteLine("U" + "nity"); = Unity
            // Console.WriteLine(true + null); = Ture


            // 5. 다음 중 변수의 이름으로 사용할 수 있는 것은?(모두 고르시오)
            // a. _ystem = 1; = O
            // b. channel#5 = 2; = X
            // c. 7eleven = 3; = X
            // d. using = 4; = X
            // e. 유니티 = 5; = O
            // f. new = 6; = O
            // g. $MAX_NUM = 7; = X
            // h. hello_com = 8; = O


            int a = 100;
            float b = 3.14f;
            string c = "12345";
            string d = "7.16";
            // 6. 위 4개의 변수들을 원하시는 형태로 형변환을 진행해주세요.(아는 부분대로 진행해 주시면 됩니다.)
            string z = Convert.ToInt32(a);
            string x = Convert.ToInt32(b);
            int y = c.ToString();
            float u = float.Parse(d);

            // 7. 다음 중 변수를 잘못 초기화한 것은? (모두 고르시고, 이유도 적어주세요)
            // a. char e = ''; = O
            // b. char annswer = 'no'; = char은 한 글자만 넣을 수 있음
            // c. float f = 3.14; = O
            // d. int g = 7.16; = int는 정수만 가능


            // 8. 사용자에게 두 개의 수를 입력 받아 곱헤 준 뒤, 출력해주는 프로그램을 자유롭게 작성하세요.
            //            using System;

            //namespace Abc
            //    {
            //        class MainApp
            //        {
            //            public static void Main()
            //            {
            //                Console.WriteLine("숫자1");
            //                string q = Console.ReadLine();

            //                Console.WriteLine("숫자2");
            //                string w = Console.ReadLine();

            //                int a = Convert.ToInt32(q);
            //                int b = Convert.ToInt32(w);
            //                int c = (a * b);

            //                Console.WriteLine("값 : {0}", c);
            //            }
            //        }
            //    }

            // 9. 사용자에게 두 개의 수를 입력 받아 나눠 준 뒤, 출력해주는 프로그램을 자유롭게 작성하세요.
            //            using System;

            //namespace Sksnttpa
            //    {
            //        class MainApp
            //        {
            //            public static void Main()
            //            {
            //                Console.WriteLine("숫자1");
            //                string q = Console.ReadLine();

            //                Console.WriteLine("숫자2");
            //                string w = Console.ReadLine();

            //                int a = Convert.ToInt32(q);
            //                int b = Convert.ToInt32(w);

            //                Console.WriteLine($"값 : {a / b}({a % b})");
            //            }
            //        }
            //    }

            // 10. 사용자에게 네 개의 수를 입력 받아 합해 준 뒤, 출력해주는 프로그램을 자유롭게 작성하세요.
            //            using System;

            //namespace Spro
            //    {
            //        class MainApp
            //        {
            //            public static void Main()
            //            {
            //                Console.WriteLine("숫자1");
            //                string q = Console.ReadLine();

            //                Console.WriteLine("숫자2");
            //                string w = Console.ReadLine();

            //                Console.WriteLine("숫자3");
            //                string e = Console.ReadLine();

            //                Console.WriteLine("숫자4");
            //                string r = Console.ReadLine();

            //                int a = Convert.ToInt32(q);
            //                int b = Convert.ToInt32(w);
            //                int c = Convert.ToInt32(e);
            //                int d = Convert.ToInt32(r);
            //                int f = a + b + c + d;

            //                Console.WriteLine("값 : {0}", d);
            //            }
            //        }
            //    }

        }
    }
}